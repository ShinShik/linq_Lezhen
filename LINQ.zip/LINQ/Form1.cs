﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ
{


    public partial class Form1 : Form
    {
        List<Department> list = new List<Department>();
        public Form1()
        {
            InitializeComponent();

            StreamReader sr = File.OpenText("txt.txt");
            while (!sr.EndOfStream)
            {
                string[] line = sr.ReadLine().Split(new char[] { ' ' });
                Department depp = new Department(line[0], line[1], line[2], int.Parse(line[3]), int.Parse(line[4]));
                list.Add(depp);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var department = from depart in list
                             where depart.Years < 40
                             select depart;
            foreach (Department d in department)
            {
                listBox1.Items.Add($"{d.Name} {d.Surname} {d.Patronymic} {d.Weight} {d.Years}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<Department> Department = new List<Department>()
                {
                new Department { Name = "Отдел закупок", Reg ="Германия" },
                new Department { Name = "Отдел продаж", Reg ="Испания" },
                new Department { Name = "Отдел маркетинга", Reg ="Исландия" }
                };
            List<Employ> employs = new List<Employ>()
            {
            new Employ { Name ="Иванов", department ="Отдел закупок"},
            new Employ { Name="Петров", department ="Отдел закупок"},
            new Employ { Name="Сидоров", department ="Отдел продаж"},
            new Employ { Name="Лямин", department ="Отдел продаж"},
            new Employ { Name="Сидоренко", department ="Отдел маркетинга"},
            new Employ { Name="Кривоносов", department ="Отдел продаж"}
            };
            listBox2.Items.Clear();
            var result = from emp in employs
                         join dep in Department on emp.department equals dep.Name
                         group emp by dep.Reg into g
                         select new { Reg = g.Key, departamet = g.ToList() };
            foreach (var item1 in result)
            {
                listBox2.Items.Add($"Регион {item1.Reg}");
                foreach (var dep1 in item1.departamet)
                {
                    listBox2.Items.Add(dep1.Name);
                }
            }

            listBox3.Items.Clear();
            var result1 = from res in result
                          where res.Reg[0] == 'И'
                          select res;
            foreach (var item1 in result1)
            {
                {
                    listBox3.Items.Add($"Регион {item1.Reg}");
                    foreach (var dep1 in item1.departamet)
                    {
                        listBox3.Items.Add(dep1.Name);
                    }
                }
                
            }
        }
    }
}
