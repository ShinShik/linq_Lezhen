﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ
{
        internal class Employ : Department
        {
            public string department { get; set; }
        }
        internal class Department
        {
            public string Name { get; set; }
            public string Surname { get; set; }
            public string Patronymic { get; set; }
            public int Years { get; set; }
            public int Weight { get; set; }
            public string Reg { get; set; }


            public Department(string surname, string name, string patronymic, int years, int weight)
            {
                this.Name = name;
                this.Surname = surname;
                this.Patronymic = patronymic;
                this.Years = years;
                this.Weight = weight;
            }
            public Department() 
            {

            }
        }
}
